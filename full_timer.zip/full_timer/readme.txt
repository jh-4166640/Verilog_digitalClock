안되는 부분 setting 모드에서 setting 모드 해제 할 때 값이 저장이 안 됌 
24진 카운터 안돼